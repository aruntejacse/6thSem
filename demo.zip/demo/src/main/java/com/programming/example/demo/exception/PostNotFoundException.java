package com.programming.example.demo.exception;

public class PostNotFoundException extends RuntimeException {

	public PostNotFoundException(String message) {
        super(message);
    }
}
