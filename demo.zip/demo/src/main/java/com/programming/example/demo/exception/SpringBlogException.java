package com.programming.example.demo.exception;

public class SpringBlogException extends RuntimeException {
    public SpringBlogException(String message) {
        super(message);
    }
}
