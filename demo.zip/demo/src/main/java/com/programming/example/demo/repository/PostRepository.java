package com.programming.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.programming.example.demo.model.Post;

public interface PostRepository extends JpaRepository<Post, Long> {
	
}